package com.capgemini.clf.libraryservlet.service;

import com.capgemini.clf.libraryservlet.model.Book;

public interface BookService {
	public boolean addBook(Book book);
	public boolean updateBook(Book book);
	public boolean deleteBook(int bid);
	public Book searchBook(int bid);


}
