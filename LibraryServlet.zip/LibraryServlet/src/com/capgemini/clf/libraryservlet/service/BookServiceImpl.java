package com.capgemini.clf.libraryservlet.service;

import com.capgemini.clf.libraryservlet.dao.BookDao;
import com.capgemini.clf.libraryservlet.dao.BookDaoImpl;
import com.capgemini.clf.libraryservlet.model.Book;

public class BookServiceImpl implements BookService {
	BookDao dao = new BookDaoImpl();

	@Override
	public boolean addBook(Book book) {
		return dao.addBook(book);
		
	}

	@Override
	public boolean updateBook(Book book) {
		return dao.updateBook(book);
	}

	@Override
	public boolean deleteBook(int bid) {
		return dao.deleteBook(bid);
	}

	@Override
	public Book searchBook(int bid) {
		return dao.searchBook(bid);
	}

}
