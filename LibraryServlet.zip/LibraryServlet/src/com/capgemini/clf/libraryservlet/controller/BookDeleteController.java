package com.capgemini.clf.libraryservlet.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.clf.libraryservlet.model.Book;
import com.capgemini.clf.libraryservlet.service.BookService;
import com.capgemini.clf.libraryservlet.service.BookServiceImpl;

@WebServlet("/deletebook")
public class BookDeleteController extends HttpServlet{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String bookid = req.getParameter("bid");
		int bid = Integer.parseInt(bookid);

		BookService bs = new BookServiceImpl();

		boolean b = bs.deleteBook(bid);
		PrintWriter out = resp.getWriter();
		if(b) {
			out.println(b);
		}else {
			out.println("Worng Credentials...");
		}
	}


}
