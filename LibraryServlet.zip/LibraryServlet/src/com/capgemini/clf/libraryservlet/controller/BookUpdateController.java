package com.capgemini.clf.libraryservlet.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.clf.libraryservlet.model.Book;
import com.capgemini.clf.libraryservlet.service.BookService;
import com.capgemini.clf.libraryservlet.service.BookServiceImpl;

@WebServlet("/updateServ")
public class BookUpdateController extends HttpServlet{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
		int bid=Integer.parseInt(id);
		String bname = req.getParameter("bname");
		String bauthor = req.getParameter("bauthor");
		String bpublisher = req.getParameter("bpublisher");

		Book book = new Book();
		book.setBid(bid);
		book.setbName(bname);
		book.setbAuthor(bauthor);
		book.setbPublisher(bpublisher);
		
		PrintWriter out = resp.getWriter();
		
		BookService bs = new BookServiceImpl();
	
		boolean bb = bs.updateBook(book);
		
		if(bb) {
			out.println("Book Updated....");
		}
		else {
			out.println("Something Went Wrong....");
		}
	
	

}
}