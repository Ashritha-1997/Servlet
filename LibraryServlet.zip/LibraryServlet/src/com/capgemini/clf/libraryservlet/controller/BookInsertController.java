package com.capgemini.clf.libraryservlet.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.clf.libraryservlet.model.Book;
import com.capgemini.clf.libraryservlet.service.BookService;
import com.capgemini.clf.libraryservlet.service.BookServiceImpl;

@WebServlet("/addbook")
public class BookInsertController extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
		int bid=Integer.parseInt(id);
		String bname = req.getParameter("bname");
		String bauthor = req.getParameter("bauthor");
		String bpublisher = req.getParameter("bpublisher");

		Book b = new Book();
		b.setBid(bid);
		b.setbName(bname);
		b.setbAuthor(bauthor);
		b.setbPublisher(bpublisher);
		
		BookService bs = new BookServiceImpl();

		boolean bb=bs.addBook(b);

		PrintWriter out = resp.getWriter();


		if(bb){
			out.println("Book Created....");
		}else {
			out.println("Something went Wrong");
		}

	}

}
