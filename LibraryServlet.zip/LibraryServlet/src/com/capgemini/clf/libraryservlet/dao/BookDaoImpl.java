package com.capgemini.clf.libraryservlet.dao;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.clf.libraryservlet.dbUtils.DBUtils;
import com.capgemini.clf.libraryservlet.model.Book;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class BookDaoImpl implements BookDao {

	private static final String INSERT_BOOK_SQL = "INSERT INTO book"
			+ "  (bid, BName, BAuthor, BPublisher) VALUES " + " (?, ?, ?, ?);";

	private static final String SELECT_BOOK_BY_ID = "select bid,BName,BAuthor,BPublisher  from book where bid =?";
	private static final String DELETE_BOOK_BY_ID = "delete from book where bid = ?;";
	private static final String UPDATE_BOOK = "update book set bid = ?, BName= ?, BAuthor =?, BPublisher =? where bid = ?";

	@Override
	public boolean addBook(Book book) {
		System.out.println(INSERT_BOOK_SQL);
		// try-with-resource statement will auto close the connection.
		try (Connection connection = DBUtils.getConnection();
				PreparedStatement preparedStatement = (PreparedStatement) connection.prepareStatement(INSERT_BOOK_SQL)) {
			preparedStatement.setInt(1, book.getBid());
			preparedStatement.setString(2, book.getbName());
			preparedStatement.setString(3, book.getbAuthor());
			preparedStatement.setString(4, book.getbPublisher());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException exception) {
			DBUtils.printSQLException(exception);
		}
		return false;
	}

	@Override
	public boolean updateBook(Book book) {
		boolean rowUpdated = false;
		try (Connection connection = DBUtils.getConnection();
				PreparedStatement statement = (PreparedStatement) connection.prepareStatement(UPDATE_BOOK);) {
			statement.setInt(1, book.getBid());
			statement.setString(2, book.getbName());
			statement.setString(3, book.getbAuthor());
			statement.setString(4, book.getbPublisher());
			statement.setLong(6, book.getBid());
			rowUpdated = statement.executeUpdate() > 0;
		} catch (SQLException e) {
			DBUtils.printSQLException(e);
		}
		return rowUpdated;
	}
	

	@Override
	public boolean deleteBook(int bid) {
		boolean rowDeleted = false;
		try (Connection connection = DBUtils.getConnection();
				PreparedStatement statement = (PreparedStatement) connection.prepareStatement(DELETE_BOOK_BY_ID);) {
			statement.setInt(1, bid);
			rowDeleted = statement.executeUpdate() > 0;
		} catch (SQLException e) {
			DBUtils.printSQLException(e);
		}
		return rowDeleted;
	}

	@Override
	public Book searchBook(int bid) {
		Book book = null;
		// Step 1: Establishing a Connection
		try (Connection connection = DBUtils.getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = (PreparedStatement) connection.prepareStatement(SELECT_BOOK_BY_ID);) {
			preparedStatement.setInt(1, bid);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int id = rs.getInt("Bid");
				String bName = rs.getString("BName");
				String bAuthor = rs.getString("BAuthor");
				String bPublisher = rs.getString("BPublisher");
				book = new Book(id, bName, bAuthor, bPublisher);
			}
		} catch (SQLException e) {
			DBUtils.printSQLException(e);
		}
		return book;
	}



}
