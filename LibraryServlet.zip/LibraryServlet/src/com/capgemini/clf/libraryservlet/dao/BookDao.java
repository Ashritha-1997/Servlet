package com.capgemini.clf.libraryservlet.dao;



import com.capgemini.clf.libraryservlet.model.Book;

public interface BookDao {
	
	public boolean addBook(Book book);
	public boolean updateBook(Book book);
	public boolean deleteBook(int bid);
	public Book searchBook(int bid);

}
